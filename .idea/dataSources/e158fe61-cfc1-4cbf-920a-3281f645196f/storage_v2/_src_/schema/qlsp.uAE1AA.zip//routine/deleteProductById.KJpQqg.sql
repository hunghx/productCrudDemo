create
    definer = root@localhost procedure deleteProductById(IN code_product int)
begin
    delete from product where code = code_product;
end;

