create
    definer = root@localhost procedure findAllProducts()
begin
    select * from product;
end;

