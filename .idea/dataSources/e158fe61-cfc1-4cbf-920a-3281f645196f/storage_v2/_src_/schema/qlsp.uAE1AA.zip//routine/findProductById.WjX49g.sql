create
    definer = root@localhost procedure findProductById(IN code_product int)
begin
    select * from product where code = code_product;
end;

