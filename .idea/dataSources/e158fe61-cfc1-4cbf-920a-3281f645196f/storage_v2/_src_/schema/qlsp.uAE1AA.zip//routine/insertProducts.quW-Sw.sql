create
    definer = root@localhost procedure insertProducts(IN new_product_name varchar(50), IN product_image varchar(100),
                                                      IN product_price double, IN product_stock int)
begin
    insert into product (product_name, image_url, price, stock) values
            (new_product_name,product_image,product_price,product_stock);
end;

