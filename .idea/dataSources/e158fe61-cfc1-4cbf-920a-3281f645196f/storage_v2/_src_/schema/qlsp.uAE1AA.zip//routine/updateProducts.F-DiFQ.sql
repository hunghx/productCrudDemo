create
    definer = root@localhost procedure updateProducts(IN code_product_update int, IN new_product_name varchar(50),
                                                      IN product_image varchar(100), IN product_price double,
                                                      IN product_stock int)
begin
    update product set product_name = new_product_name, image_url=product_image, price=product_price, stock = product_stock  where code = code_product_update;
end;

